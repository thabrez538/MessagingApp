package com.telstra.messagingapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/users")
public class UserController {
	@Autowired
	private UserService userservice;
	
	@PostMapping
	public ResponseEntity<String> createUser(@RequestBody User user){
		userservice.createUser(user);
		return ResponseEntity.ok("User Created Successfully");
	}
	
	@GetMapping("/{username}")
	public ResponseEntity<User> getUserByUserName(@PathVariable String username){
		User user=userservice.getuserByUsername(username);
		if(user!=null) {
			return ResponseEntity.ok(user);
		}
		else {
			return ResponseEntity.notFound().build();
		}
	}
}
