package com.telstra.messagingapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class UserDetailsConfig {
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Bean
	public UserDetailsService userDetailsService(){
		return username->{
			User user=userRepository.findByUsername(username);
			
			if(user==null) {
				throw new UsernameNotFoundException("Username not found with username:"+username);
			}
			UserDetails userDetails=new org.springframework.security.core.userdetails.User(
					user.getUsername(),
					user.getPassword(),
					true,true,true,true,
					AuthorityUtils.createAuthorityList("ROLE_USER"));
					
			return userDetails;
		};
	}
}
